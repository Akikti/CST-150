Project Title:
	Activity 1

Build Status:
	Complete

Video:
	https://screenpal.com/watch/c0fo0HVaRTr

Framework:
	.NET

Features:
	TextBoxes, Labels, CheckBox, Buttons

The forms allows for the user to enter a username and password.  They can then check the CheckBox stating they
 are not a robot, and either clear the fields or Login. Once they are logged in, they are presented with a login message.