Project Title:
	Activity 1
	
Build Status:
	Complete
	
Video:
	https://www.loom.com/share/d21f4a34f8a443c78029f8e546a60499
	
Framework:
	.NET

Features:
	textBox, radioButton, button, labels
	
The form allows for information to be entered into the textBoxes that 
is asked for in the labels.  You may click the radioButton to agree
to the terms of serive and the button allows you to clear the information 
contained in the form.